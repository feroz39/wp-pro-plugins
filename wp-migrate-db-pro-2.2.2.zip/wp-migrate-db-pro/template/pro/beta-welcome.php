<?php defined( 'ABSPATH' ) || exit; ?>
<div class="below-title beta-welcome warning inline-message">
	<h3>THANKS FOR TRYING THE BETA OF WP MIGRATE DB PRO 2.0</h3>
	<p>Please report any bugs you find on the <a href="#help">Help tab</a>.</p>
</div>
