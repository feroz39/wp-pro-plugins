<?php

$GLOBALS['wpmdb_meta']['wp-migrate-db-pro-multisite-tools']['version'] = '1.4.1';
